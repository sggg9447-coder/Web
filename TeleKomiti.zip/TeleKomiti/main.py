"""
Komiti Plus Telegram Bot - Complete Implementation
Features: Multi-language support, gift codes, enhanced game system, admin controls
"""

import asyncio
import json
import random
import os
import re
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, F
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

# Import utilities
from utils.language import get_text, get_language_keyboard, LANGUAGES
from utils.helpers import (
    generate_user_id, generate_gift_code, get_user_profile, update_user_profile,
    get_game_ranges, calculate_prize_pool, find_winners, format_winners_list,
    create_game_history_entry, validate_gift_code, redeem_gift_code,
    get_top_players, format_players_list, create_gift_code_entry,
    get_unused_codes, ensure_unique_user_id
)

# === Config ===
BOT_TOKEN = os.getenv("BOT_TOKEN", "7738918604:AAHrds_8MiZVXvZf5Od3I775G5pLtOP5I88")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "@Ahmad_khan_111")

# Data files
USERS_FILE = "data/users.json"
GAME_FILE = "data/game_state.json"
CODES_FILE = "data/codes.json"
HISTORY_FILE = "data/history.json"
ADMIN_WALLET_FILE = "data/admin_wallet.json"

# FSM States
class RedeemState(StatesGroup):
    waiting_for_code = State()

class AdminState(StatesGroup):
    waiting_for_points_amount = State()
    waiting_for_target_user = State()
    waiting_for_code_points = State()
    waiting_for_user_to_send_points = State()
    waiting_for_user_to_remove_points = State()
    waiting_for_game_settings = State()
    waiting_for_winning_number = State()
    waiting_for_custom_range = State()
    waiting_for_custom_cost = State()

# Ensure data directory exists
os.makedirs("data", exist_ok=True)

# === Helpers: JSON I/O ===
def load_json(path):
    """Load JSON data from file, create empty dict if file doesn't exist"""
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump({}, f)
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return {}

def save_json(path, data):
    """Save data to JSON file with proper formatting"""
    with open(path, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Load initial data
users = load_json(USERS_FILE)
game_state = load_json(GAME_FILE)
gift_codes = load_json(CODES_FILE)
game_history = load_json(HISTORY_FILE)
admin_wallet = load_json(ADMIN_WALLET_FILE)

# Initialize admin wallet if empty
if not admin_wallet:
    admin_wallet = {"points": 0, "total_collected": 0}

# Global variable to store current game task
current_game_task = None

# === Bot Init ===
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=storage)

# === Admin Helper ===
def is_admin(message_or_user) -> bool:
    """Check if user is admin based on username"""
    if isinstance(message_or_user, (Message, CallbackQuery)):
        if not message_or_user.from_user:
            return False
        username = message_or_user.from_user.username
    else:
        username = message_or_user
    
    if not username:
        return False
    
    admin_clean = ADMIN_USERNAME.lower().replace("@", "")
    user_clean = username.lower().replace("@", "")
    
    return user_clean == admin_clean

# === Helper Functions ===
async def save_all_data():
    """Save all data to files"""
    save_json(USERS_FILE, users)
    save_json(GAME_FILE, game_state)
    save_json(CODES_FILE, gift_codes)
    save_json(HISTORY_FILE, game_history)
    save_json(ADMIN_WALLET_FILE, admin_wallet)

async def show_main_menu(msg_or_callback, uid: str, lang: str):
    """Show main menu to user"""
    user = users[uid]
    points = user.get('points', 0)
    user_id = user.get('unique_id', '000000')
    
    # Create main menu keyboard
    kb = InlineKeyboardBuilder()
    kb.button(text="💰 Balance", callback_data="check_balance")
    kb.button(text="🎮 Join Game", callback_data="join_game")
    kb.button(text="🎁 Redeem Code", callback_data="redeem_code")
    kb.button(text="🌐 Language", callback_data="change_language")
    
    if is_admin(msg_or_callback):
        kb.button(text="⚙️ Admin Panel", callback_data="admin_panel")
    
    kb.button(text="ℹ️ Help", callback_data="help")
    kb.button(text="🏆 Top Players", callback_data="top_players")
    kb.adjust(2)
    
    text = get_text(lang, 'main_menu', points=points, user_id=user_id)
    
    if isinstance(msg_or_callback, Message):
        await msg_or_callback.answer(text, reply_markup=kb.as_markup())
    else:
        if msg_or_callback.message:
            await msg_or_callback.message.edit_text(text, reply_markup=kb.as_markup())

async def game_countdown_task():
    """Background task to handle game countdown and auto-end"""
    global current_game_task
    
    if not game_state.get("active"):
        return
    
    try:
        # Wait for the game duration
        game_duration = game_state.get("duration_hours", 1) * 3600
        await asyncio.sleep(game_duration)
        
        # Auto-end the game
        if game_state.get("active"):
            await end_game_auto()
            
    except asyncio.CancelledError:
        pass
    finally:
        current_game_task = None

async def end_game_auto():
    """Automatically end the current game"""
    if not game_state.get("active"):
        return
    
    winning_number = game_state.get("winning_number")
    players = game_state.get("players", {})
    
    if not players or winning_number is None:
        # No players or no winning number, just end the game
        game_state["active"] = False
        await save_all_data()
        return
    
    # Find winners
    winners = find_winners(players, winning_number)
    prize_pool = calculate_prize_pool(len(players), game_state.get("cost", 1))
    
    # Distribute prizes
    if winners:
        prize_per_winner = prize_pool // len(winners)
        for winner_uid in winners:
            users[winner_uid]['points'] += prize_per_winner
            users[winner_uid]['wins'] = users[winner_uid].get('wins', 0) + 1
    
    # Create history entry
    history_entry = create_game_history_entry(game_state, winners, prize_pool)
    game_history[datetime.now().isoformat()] = history_entry
    
    # End the game
    game_state["active"] = False
    game_state["players"] = {}
    
    await save_all_data()
    
    # Notify all users (you can implement broadcast here if needed)
    print(f"Game ended automatically. Winners: {winners}, Prize pool: {prize_pool}")

# === /start Command ===
@dp.message(F.text == "/start")
async def cmd_start(msg: Message):
    """Handle /start command with language selection for new users"""
    if not msg.from_user:
        return
    uid = str(msg.from_user.id)
    username = msg.from_user.username or f"User{uid}"
    
    if uid not in users:
        # New user - show language selection first
        kb = InlineKeyboardBuilder()
        for lang_text, lang_data in get_language_keyboard():
            kb.button(text=lang_text, callback_data=lang_data)
        kb.adjust(1)
        
        await msg.answer(
            "🎉 Welcome to **Komiti Plus**!\n\n"
            "Please select your language / د خپلې ژبې غوره کړئ / زبان خود را انتخاب کنید:",
            reply_markup=kb.as_markup()
        )
    else:
        # Existing user - show main menu
        user = users[uid]
        lang = user.get('language', 'english')
        await show_main_menu(msg, uid, lang)

# === Language Selection ===
@dp.callback_query(F.data.startswith("lang_"))
async def cb_language_select(callback: CallbackQuery):
    """Handle language selection"""
    if not callback.from_user or not callback.data:
        return
    uid = str(callback.from_user.id)
    username = callback.from_user.username or f"User{uid}"
    selected_lang = callback.data.split("_")[1]
    
    # Create or update user profile
    if uid not in users:
        users[uid] = {
            'telegram_id': uid,
            'username': username,
            'unique_id': ensure_unique_user_id(users),
            'points': 1,  # Starting bonus
            'wins': 0,
            'language': selected_lang,
            'join_date': datetime.now().isoformat()
        }
        
        # Welcome new user
        text = get_text(selected_lang, 'welcome_new')
    else:
        # Update existing user's language
        users[uid]['language'] = selected_lang
        text = get_text(selected_lang, 'language_set')
    
    await save_all_data()
    await callback.answer(get_text(selected_lang, 'language_set'))
    await show_main_menu(callback, uid, selected_lang)

# === Main Menu Callbacks ===
@dp.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    """Return to main menu"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    await show_main_menu(callback, uid, lang)
    await callback.answer()

@dp.callback_query(F.data == "check_balance")
async def cb_check_balance(callback: CallbackQuery):
    """Handle balance check button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    points = user.get('points', 0)
    wins = user.get('wins', 0)
    user_id = user.get('unique_id', '000000')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'check_balance', points=points, wins=wins, user_id=user_id)
    
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "join_game")
async def cb_join_game(callback: CallbackQuery):
    """Handle join game button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    if not game_state.get("active"):
        kb = InlineKeyboardBuilder()
        kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
        
        text = get_text(lang, 'no_active_game')
        if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
        await callback.answer()
        return
    
    if uid in game_state.get("players", {}):
        kb = InlineKeyboardBuilder()
        kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
        
        picked_num = game_state["players"][uid]
        text = get_text(lang, 'already_joined', number=picked_num)
        if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
        await callback.answer()
        return
    
    # Show number selection
    min_num = game_state.get("min_range", 1)
    max_num = game_state.get("max_range", 50)
    cost = game_state.get("cost", 1)
    balance = user.get('points', 0)
    
    if balance < cost:
        await callback.answer(get_text(lang, 'not_enough_points'), show_alert=True)
        return
    
    # Create number selection keyboard
    kb = InlineKeyboardBuilder()
    for i in range(min_num, max_num + 1):
        kb.button(text=str(i), callback_data=f"pick_{i}")
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    kb.adjust(5)
    
    text = get_text(lang, 'join_game', min_num=min_num, max_num=max_num, cost=cost, balance=balance)
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data.startswith("pick_"))
async def cb_pick_number(callback: CallbackQuery):
    """Handle number selection"""
    if not callback.from_user or not callback.data:
        return
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    if not game_state.get("active"):
        await callback.answer(get_text(lang, 'no_active_game'), show_alert=True)
        return
    
    if uid in game_state.get("players", {}):
        await callback.answer("Already joined!", show_alert=True)
        return
    
    cost = game_state.get("cost", 1)
    if user.get('points', 0) < cost:
        await callback.answer(get_text(lang, 'not_enough_points'), show_alert=True)
        return
    
    # Process the pick
    num = int(callback.data.split("_")[1])
    
    # Update game state
    if "players" not in game_state:
        game_state["players"] = {}
    game_state["players"][uid] = num
    
    # Deduct entry fee and add to admin wallet
    users[uid]['points'] -= cost
    admin_wallet['points'] += cost
    admin_wallet['total_collected'] += cost
    
    await save_all_data()
    
    text = get_text(lang, 'number_picked', number=num)
    await callback.answer(text)
    
    # Return to main menu
    await show_main_menu(callback, uid, lang)

@dp.callback_query(F.data == "redeem_code")
async def cb_redeem_code(callback: CallbackQuery, state: FSMContext):
    """Handle redeem code button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'redeem_prompt')
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(RedeemState.waiting_for_code)
    await callback.answer()

@dp.message(RedeemState.waiting_for_code)
async def handle_redeem_code(msg: Message, state: FSMContext):
    """Handle gift code redemption"""
    if not msg.from_user or not msg.text:
        return
    uid = str(msg.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    code = msg.text.strip().upper()
    
    success, result, points = redeem_gift_code(gift_codes, users, code, uid)
    
    if success:
        text = get_text(lang, 'redeem_success', points=points, balance=users[uid]['points'])
    elif result == "used":
        text = get_text(lang, 'redeem_used')
    else:
        text = get_text(lang, 'redeem_invalid')
    
    await save_all_data()
    await msg.answer(text)
    await state.clear()
    
    # Show main menu
    await show_main_menu(msg, uid, lang)

@dp.callback_query(F.data == "change_language")
async def cb_change_language(callback: CallbackQuery):
    """Handle language change"""
    kb = InlineKeyboardBuilder()
    for lang_text, lang_data in get_language_keyboard():
        kb.button(text=lang_text, callback_data=lang_data)
    kb.adjust(1)
    
    if callback.message:
            await callback.message.edit_text(
        "Select your language / د خپلې ژبې غوره کړئ / زبان خود را انتخاب کنید:",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

@dp.callback_query(F.data == "top_players")
async def cb_top_players(callback: CallbackQuery):
    """Show top players leaderboard"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    top_players_list = get_top_players(users, 10)
    players_text = format_players_list(top_players_list, users)
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'top_players', players=players_text)
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    """Show help information"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'help')
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

# === Admin Panel ===
@dp.callback_query(F.data == "admin_panel")
async def cb_admin_panel(callback: CallbackQuery):
    """Show admin panel (admin only)"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🎮 Start Game", callback_data="admin_start_game")
    kb.button(text="⏹️ End Game", callback_data="admin_end_game")
    kb.button(text="💰 Send Points", callback_data="admin_send_points")
    kb.button(text="➖ Remove Points", callback_data="admin_remove_points")
    kb.button(text="🎁 Generate Code", callback_data="admin_generate_code")
    kb.button(text="👥 View Players", callback_data="admin_view_players")
    kb.button(text="💼 Admin Wallet", callback_data="admin_wallet")
    kb.button(text="🔙 Back to Menu", callback_data="main_menu")
    kb.adjust(2)
    
    text = "⚙️ <b>Admin Panel</b>\n\nSelect an action:"
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "admin_start_game")
async def cb_admin_start_game(callback: CallbackQuery, state: FSMContext):
    """Admin: Start new game"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    if game_state.get("active"):
        await callback.answer("Game is already active!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="1-50 (1 point)", callback_data="game_setup_1_50_1")
    kb.button(text="1-100 (2 points)", callback_data="game_setup_1_100_2")
    kb.button(text="1-500 (5 points)", callback_data="game_setup_1_500_5")
    kb.button(text="1-1000 (10 points)", callback_data="game_setup_1_1000_10")
    kb.button(text="⚙️ Custom Setup", callback_data="game_custom_setup")
    kb.button(text="🔙 Back", callback_data="admin_panel")
    kb.adjust(2)
    
    text = "🎮 <b>Start New Game</b>\n\nSelect game settings:"
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data.startswith("game_setup_"))
async def cb_game_setup(callback: CallbackQuery, state: FSMContext):
    """Handle game setup"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    # Parse setup data
    parts = callback.data.split("_")[2:]  # Skip "game_setup"
    min_range = int(parts[0])
    max_range = int(parts[1])
    cost = int(parts[2])
    
    # Store setup in state
    await state.update_data(min_range=min_range, max_range=max_range, cost=cost)
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_start_game")
    
    text = (f"🎯 <b>Set Winning Number</b>\n\n"
            f"Range: {min_range}-{max_range}\n"
            f"Cost: {cost} points\n\n"
            f"Enter the winning number ({min_range}-{max_range}):")
    
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(AdminState.waiting_for_winning_number)
    await callback.answer()

@dp.message(AdminState.waiting_for_winning_number)
async def handle_winning_number(msg: Message, state: FSMContext):
    """Handle winning number input"""
    if not is_admin(msg):
        await msg.answer("Access denied!")
        return
    
    try:
        winning_number = int(msg.text.strip())
        data = await state.get_data()
        min_range = data['min_range']
        max_range = data['max_range']
        cost = data['cost']
        
        if not (min_range <= winning_number <= max_range):
            await msg.answer(f"Number must be between {min_range} and {max_range}!")
            return
        
        # Initialize new game
        global current_game_task
        
        game_state.update({
            "active": True,
            "min_range": min_range,
            "max_range": max_range,
            "cost": cost,
            "winning_number": winning_number,
            "players": {},
            "start_time": datetime.now().isoformat(),
            "duration_hours": 1
        })
        
        await save_all_data()
        await state.clear()
        
        # Start countdown task
        if current_game_task:
            current_game_task.cancel()
        current_game_task = asyncio.create_task(game_countdown_task())
        
        text = (f"✅ <b>Game Started!</b>\n\n"
                f"🎯 Range: {min_range}-{max_range}\n"
                f"💰 Cost: {cost} points\n"
                f"⏰ Duration: 1 hour\n"
                f"🔢 Winning Number: {winning_number} (secret)")
        
        await msg.answer(text)
        
        # Return to admin panel
        uid = str(msg.from_user.id)
        user = users.get(uid, {})
        lang = user.get('language', 'english')
        await show_main_menu(msg, uid, lang)
        
    except ValueError:
        await msg.answer("Please enter a valid number!")

@dp.callback_query(F.data == "game_custom_setup")
async def cb_game_custom_setup(callback: CallbackQuery, state: FSMContext):
    """Admin: Custom game setup"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_start_game")
    
    text = ("⚙️ <b>Custom Game Setup</b>\n\n"
            "Enter the number range (e.g., '1-250' or '50-500'):")
    
    if callback.message:
        await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(AdminState.waiting_for_custom_range)
    await callback.answer()

@dp.message(AdminState.waiting_for_custom_range)
async def handle_custom_range(msg: Message, state: FSMContext):
    """Handle custom range input"""
    if not is_admin(msg) or not msg.text:
        await msg.answer("Access denied!")
        return
    
    try:
        # Parse range (e.g., "1-250" or "50-500")
        range_parts = msg.text.strip().split('-')
        if len(range_parts) != 2:
            await msg.answer("Please enter range in format: 1-250")
            return
            
        min_range = int(range_parts[0])
        max_range = int(range_parts[1])
        
        if min_range >= max_range or min_range < 1:
            await msg.answer("Invalid range! Min must be less than max and both positive.")
            return
            
        # Store range in state
        await state.update_data(min_range=min_range, max_range=max_range)
        
        # Ask for entry cost
        kb = InlineKeyboardBuilder()
        kb.button(text="🔙 Back", callback_data="admin_start_game")
        
        text = (f"⚙️ <b>Custom Game Setup</b>\n\n"
                f"Range: {min_range}-{max_range}\n\n"
                f"Now enter the entry cost (points required to join):")
        
        await msg.answer(text, reply_markup=kb.as_markup())
        await state.set_state(AdminState.waiting_for_custom_cost)
        
    except ValueError:
        await msg.answer("Please enter a valid range (e.g., 1-250)")

@dp.message(AdminState.waiting_for_custom_cost)
async def handle_custom_cost(msg: Message, state: FSMContext):
    """Handle custom entry cost input"""
    if not is_admin(msg) or not msg.text:
        await msg.answer("Access denied!")
        return
    
    try:
        cost = int(msg.text.strip())
        if cost < 1:
            await msg.answer("Entry cost must be at least 1 point!")
            return
            
        # Get range from state
        data = await state.get_data()
        min_range = data['min_range']
        max_range = data['max_range']
        
        # Store all setup data
        await state.update_data(min_range=min_range, max_range=max_range, cost=cost)
        
        # Ask for winning number
        kb = InlineKeyboardBuilder()
        kb.button(text="🔙 Back", callback_data="admin_start_game")
        
        text = (f"🎯 <b>Set Winning Number</b>\n\n"
                f"Range: {min_range}-{max_range}\n"
                f"Entry Cost: {cost} points\n\n"
                f"Enter the winning number ({min_range}-{max_range}):")
        
        await msg.answer(text, reply_markup=kb.as_markup())
        await state.set_state(AdminState.waiting_for_winning_number)
        
    except ValueError:
        await msg.answer("Please enter a valid number for entry cost!")

@dp.callback_query(F.data == "admin_end_game")
async def cb_admin_end_game(callback: CallbackQuery):
    """Admin: End current game"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    if not game_state.get("active"):
        await callback.answer("No active game!", show_alert=True)
        return
    
    # End the game manually
    global current_game_task
    if current_game_task:
        current_game_task.cancel()
    
    await end_game_auto()
    
    await callback.answer("Game ended successfully!")
    await cb_admin_panel(callback)

@dp.callback_query(F.data == "admin_send_points")
async def cb_admin_send_points(callback: CallbackQuery, state: FSMContext):
    """Admin: Send points to user"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_panel")
    
    text = "💰 <b>Send Points</b>\n\nEnter amount to send:"
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(AdminState.waiting_for_points_amount)
    await callback.answer()

@dp.message(AdminState.waiting_for_points_amount)
async def handle_points_amount(msg: Message, state: FSMContext):
    """Handle points amount input"""
    if not is_admin(msg):
        await msg.answer("Access denied!")
        return
    
    try:
        amount = int(msg.text.strip())
        if amount <= 0:
            await msg.answer("Amount must be positive!")
            return
        
        await state.update_data(points_amount=amount)
        
        text = f"💰 Sending {amount} points\n\nEnter user ID (6-digit) or @username:"
        await msg.answer(text)
        await state.set_state(AdminState.waiting_for_user_to_send_points)
        
    except ValueError:
        await msg.answer("Please enter a valid number!")

@dp.message(AdminState.waiting_for_user_to_send_points)
async def handle_send_points_target(msg: Message, state: FSMContext):
    """Handle target user for sending points"""
    if not is_admin(msg):
        await msg.answer("Access denied!")
        return
    
    target = msg.text.strip()
    data = await state.get_data()
    amount = data['points_amount']
    
    # Find user
    target_user = None
    target_uid = None
    
    if target.startswith('@'):
        # Search by username
        username = target[1:].lower()
        for uid, user in users.items():
            if user.get('username', '').lower() == username:
                target_user = user
                target_uid = uid
                break
    else:
        # Search by unique ID
        for uid, user in users.items():
            if user.get('unique_id') == target:
                target_user = user
                target_uid = uid
                break
    
    if not target_user:
        await msg.answer("User not found!")
        return
    
    # Send points
    target_user['points'] += amount
    admin_wallet['points'] -= min(admin_wallet['points'], amount)  # Deduct from admin if available
    
    await save_all_data()
    await state.clear()
    
    username = target_user.get('username', 'Unknown')
    unique_id = target_user.get('unique_id', '000000')
    
    await msg.answer(f"✅ Sent {amount} points to @{username} (ID: {unique_id})")
    
    # Return to menu
    uid = str(msg.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    await show_main_menu(msg, uid, lang)

@dp.callback_query(F.data == "admin_remove_points")
async def cb_admin_remove_points(callback: CallbackQuery, state: FSMContext):
    """Admin: Remove points from user"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_panel")
    
    text = "➖ <b>Remove Points</b>\n\nEnter user ID (6-digit) or @username:"
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(AdminState.waiting_for_user_to_remove_points)
    await callback.answer()

@dp.message(AdminState.waiting_for_user_to_remove_points)
async def handle_remove_points_target(msg: Message, state: FSMContext):
    """Handle target user for removing points"""
    if not is_admin(msg):
        await msg.answer("Access denied!")
        return
    
    target = msg.text.strip()
    
    # Find user
    target_user = None
    target_uid = None
    
    if target.startswith('@'):
        # Search by username
        username = target[1:].lower()
        for uid, user in users.items():
            if user.get('username', '').lower() == username:
                target_user = user
                target_uid = uid
                break
    else:
        # Search by unique ID
        for uid, user in users.items():
            if user.get('unique_id') == target:
                target_user = user
                target_uid = uid
                break
    
    if not target_user:
        await msg.answer("User not found!")
        return
    
    await state.update_data(target_uid=target_uid)
    
    current_points = target_user.get('points', 0)
    username = target_user.get('username', 'Unknown')
    unique_id = target_user.get('unique_id', '000000')
    
    text = (f"➖ <b>Remove Points</b>\n\n"
            f"User: @{username} (ID: {unique_id})\n"
            f"Current Points: {current_points}\n\n"
            f"Enter amount to remove:")
    
    await msg.answer(text)
    await state.set_state(AdminState.waiting_for_points_amount)

@dp.callback_query(F.data == "admin_generate_code")
async def cb_admin_generate_code(callback: CallbackQuery, state: FSMContext):
    """Admin: Generate gift code"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_panel")
    
    text = "🎁 <b>Generate Gift Code</b>\n\nEnter points value for the code:"
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(AdminState.waiting_for_code_points)
    await callback.answer()

@dp.message(AdminState.waiting_for_code_points)
async def handle_code_points(msg: Message, state: FSMContext):
    """Handle gift code points input"""
    if not is_admin(msg):
        await msg.answer("Access denied!")
        return
    
    try:
        points = int(msg.text.strip())
        if points <= 0:
            await msg.answer("Points must be positive!")
            return
        
        # Generate unique code
        code = generate_gift_code()
        gift_codes[code] = create_gift_code_entry(points)
        
        await save_all_data()
        await state.clear()
        
        text = (f"✅ <b>Gift Code Generated!</b>\n\n"
                f"🎁 Code: <code>{code}</code>\n"
                f"💰 Value: {points} points\n"
                f"📋 Click to copy the code")
        
        await msg.answer(text)
        
        # Return to menu
        uid = str(msg.from_user.id)
        user = users.get(uid, {})
        lang = user.get('language', 'english')
        await show_main_menu(msg, uid, lang)
        
    except ValueError:
        await msg.answer("Please enter a valid number!")

@dp.callback_query(F.data == "admin_view_players")
async def cb_admin_view_players(callback: CallbackQuery):
    """Admin: View current game players"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_panel")
    
    if not game_state.get("active"):
        text = "No active game!"
    else:
        players = game_state.get("players", {})
        if not players:
            text = "🎮 <b>Current Game</b>\n\nNo players joined yet."
        else:
            text = f"🎮 <b>Current Game Players ({len(players)})</b>\n\n"
            for uid, number in players.items():
                user = users.get(uid, {})
                username = user.get('username', 'Unknown')
                unique_id = user.get('unique_id', '000000')
                text += f"• @{username} (ID: {unique_id}) → {number}\n"
    
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "admin_wallet")
async def cb_admin_wallet(callback: CallbackQuery):
    """Admin: View admin wallet"""
    if not is_admin(callback):
        await callback.answer("Access denied!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back", callback_data="admin_panel")
    
    points = admin_wallet.get('points', 0)
    total_collected = admin_wallet.get('total_collected', 0)
    
    text = (f"💼 <b>Admin Wallet</b>\n\n"
            f"💰 Current Points: {points}\n"
            f"📊 Total Collected: {total_collected}")
    
    if callback.message:
            await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

# === Error Handler ===
@dp.error()
async def error_handler(event, exception):
    """Global error handler"""
    print(f"Error: {exception}")
    return True

# === Main Function ===
async def main():
    """Main function to start the bot"""
    print("Starting Komiti Plus Bot...")
    print(f"Bot Token: {BOT_TOKEN[:10]}...")
    print(f"Admin: {ADMIN_USERNAME}")
    
    # Start polling
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
