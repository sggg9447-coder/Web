"""
Multi-language support for Komiti Plus Bot
Supports: English, Pashto, Dari
"""

# Language definitions
LANGUAGES = {
    'english': '🇺🇸 English',
    'pashto': '🇦🇫 پښتو',
    'dari': '🇦🇫 دری'
}

# Translation strings
TRANSLATIONS = {
    'english': {
        'main_menu': (
            "🎉 <b>Welcome to Komiti Plus!</b>\n\n"
            "💰 Your Balance: <b>{points} AFG</b>\n"
            "🆔 Your ID: <b>{user_id}</b>\n\n"
            "🎮 Join games and win prizes!\n"
            "🎁 Redeem gift codes for points!\n\n"
            "Select an option below:"
        ),
        'welcome_new': (
            "🎉 <b>Welcome to Komiti Plus!</b>\n\n"
            "You've received <b>1 AFG</b> as a welcome bonus!\n"
            "Start playing games and earning points!"
        ),
        'language_set': "✅ Language updated successfully!",
        'check_balance': (
            "💰 <b>Your Wallet</b>\n\n"
            "💵 Balance: <b>{points} AFG</b>\n"
            "🏆 Total Wins: <b>{wins}</b>\n"
            "🆔 Your ID: <b>{user_id}</b>\n\n"
            "Keep playing to earn more!"
        ),
        'no_active_game': (
            "🎮 <b>No Active Game</b>\n\n"
            "There's no game running right now.\n"
            "Check back later or wait for admin to start a new game!"
        ),
        'already_joined': (
            "🎮 <b>Already Joined!</b>\n\n"
            "You've already picked number <b>{number}</b> for this game.\n"
            "Wait for the results!"
        ),
        'join_game': (
            "🎮 <b>Join Current Game</b>\n\n"
            "🎯 Range: <b>{min_num} - {max_num}</b>\n"
            "💰 Entry Cost: <b>{cost} AFG</b>\n"
            "💵 Your Balance: <b>{balance} AFG</b>\n\n"
            "Select your lucky number:"
        ),
        'not_enough_points': "❌ Not enough points to join the game!",
        'number_picked': "✅ Number {number} selected! Good luck! 🍀",
        'redeem_prompt': (
            "🎁 <b>Redeem Gift Code</b>\n\n"
            "Enter your gift code below:\n"
            "(Type the code and send)"
        ),
        'redeem_success': (
            "🎉 <b>Code Redeemed Successfully!</b>\n\n"
            "💰 You received: <b>{points} AFG</b>\n"
            "💵 New Balance: <b>{balance} AFG</b>"
        ),
        'redeem_used': "❌ This code has already been used!",
        'redeem_invalid': "❌ Invalid gift code!",
        'top_players': (
            "🏆 <b>Top Players Leaderboard</b>\n\n"
            "{players}\n\n"
            "Keep playing to climb the rankings!"
        ),
        'help': (
            "ℹ️ <b>How to Play</b>\n\n"
            "🎮 <b>Game Rules:</b>\n"
            "• Join active games by selecting a number\n"
            "• Entry fee is deducted from your balance\n"
            "• Winners are closest to the secret number\n"
            "• Prize is shared among winners\n\n"
            "💰 <b>Earning Points:</b>\n"
            "• Win games to earn AFG\n"
            "• Redeem gift codes\n"
            "• Get bonuses from admin\n\n"
            "🎁 <b>Gift Codes:</b>\n"
            "• Each code can only be used once\n"
            "• Enter code exactly as shown\n\n"
            "Good luck and have fun! 🍀"
        ),
        'back_menu': '🔙 Back to Menu'
    },
    'pashto': {
        'main_menu': (
            "🎉 <b>د کمیتی پلس ته ښه راغلاست!</b>\n\n"
            "💰 ستاسو بیلنس: <b>{points} AFG</b>\n"
            "🆔 ستاسو ID: <b>{user_id}</b>\n\n"
            "🎮 په لوبو کې برخه واخلئ او جایزې وګټئ!\n"
            "🎁 د پوائنټونو لپاره د کادو کوډونه استعمال کړئ!\n\n"
            "لاندې څخه یو اختیار وټاکئ:"
        ),
        'welcome_new': (
            "🎉 <b>د کمیتی پلس ته ښه راغلاست!</b>\n\n"
            "تاسو د هرکلي بونس په توګه <b>1 AFG</b> ترلاسه کړئ!\n"
            "د لوبو پیل وکړئ او پوائنټونه وګټئ!"
        ),
        'language_set': "✅ ژبه بریالیتوب سره تازه شوه!",
        'check_balance': (
            "💰 <b>ستاسو پیسې</b>\n\n"
            "💵 بیلنس: <b>{points} AFG</b>\n"
            "🏆 ټول بریالیتوبونه: <b>{wins}</b>\n"
            "🆔 ستاسو ID: <b>{user_id}</b>\n\n"
            "د نورو پوائنټونو لپاره لوبې ته دوام ورکړئ!"
        ),
        'no_active_game': (
            "🎮 <b>فعاله لوبه نشته</b>\n\n"
            "اوس مهال کومه لوبه نه چلیږي.\n"
            "وروسته بیا وګورئ یا د اډمین لخوا د نوې لوبې انتظار وکړئ!"
        ),
        'already_joined': (
            "🎮 <b>دمخه برخه اخیستې!</b>\n\n"
            "تاسو دمخه د دغې لوبې لپاره <b>{number}</b> نمبر غوره کړې.\n"
            "د پایلو انتظار وکړئ!"
        ),
        'join_game': (
            "🎮 <b>اوسنۍ لوبې ته ورشئ</b>\n\n"
            "🎯 حد: <b>{min_num} - {max_num}</b>\n"
            "💰 د ننوتلو لګښت: <b>{cost} AFG</b>\n"
            "💵 ستاسو بیلنس: <b>{balance} AFG</b>\n\n"
            "خپله خوښمنه نمبر وټاکئ:"
        ),
        'not_enough_points': "❌ د لوبې ته د ننوتلو لپاره کافي پوائنټونه نلرئ!",
        'number_picked': "✅ {number} نمبر وټاکل شوه! ښه برخه! 🍀",
        'redeem_prompt': (
            "🎁 <b>د کادو کوډ استعمال کړئ</b>\n\n"
            "لاندې خپل د کادو کوډ ولیکئ:\n"
            "(کوډ ولیکئ او واستوئ)"
        ),
        'redeem_success': (
            "🎉 <b>کوډ بریالیتوب سره استعمال شو!</b>\n\n"
            "💰 تاسو ترلاسه کړئ: <b>{points} AFG</b>\n"
            "💵 نوی بیلنس: <b>{balance} AFG</b>"
        ),
        'redeem_used': "❌ دا کوډ دمخه استعمال شوی!",
        'redeem_invalid': "❌ د کادو کوډ سمه نده!",
        'top_players': (
            "🏆 <b>د غورو لوبغاړو لیست</b>\n\n"
            "{players}\n\n"
            "د درجه بندۍ د پورته کولو لپاره لوبې ته دوام ورکړئ!"
        ),
        'help': (
            "ℹ️ <b>څنګه لوبه وکړو</b>\n\n"
            "🎮 <b>د لوبې قوانین:</b>\n"
            "• د یوې نمبر په غوره کولو سره فعالو لوبو کې برخه واخلئ\n"
            "• د ننوتلو فیس ستاسو له بیلنس څخه کشل کیږي\n"
            "• بریالي هغه دي چې پټ نمبر ته نږدې وي\n"
            "• جایزه د ګټونکو ترمنځ ویشل کیږي\n\n"
            "💰 <b>د پوائنټونو ګټل:</b>\n"
            "• د لوبو ګټلو لپاره AFG ګټئ\n"
            "• د کادو کوډونه استعمال کړئ\n"
            "• له اډمین څخه بونس ترلاسه کړئ\n\n"
            "🎁 <b>د کادو کوډونه:</b>\n"
            "• هر کوډ یوازې یو ځل کارول کیدی شي\n"
            "• کوډ دقیقاً لکه څنګه چې ښودل شوي ولیکئ\n\n"
            "ښه برخه او ساتیري! 🍀"
        ),
        'back_menu': '🔙 بیرته مینو ته'
    },
    'dari': {
        'main_menu': (
            "🎉 <b>به کمیتی پلس خوش آمدید!</b>\n\n"
            "💰 بیلنس شما: <b>{points} AFG</b>\n"
            "🆔 ID شما: <b>{user_id}</b>\n\n"
            "🎮 در بازی‌ها شرکت کنید و جوایز ببرید!\n"
            "🎁 کدهای هدیه را برای امتیاز استفاده کنید!\n\n"
            "گزینه‌ای را انتخاب کنید:"
        ),
        'welcome_new': (
            "🎉 <b>به کمیتی پلس خوش آمدید!</b>\n\n"
            "شما <b>1 AFG</b> به عنوان پاداش خوش‌آمدگویی دریافت کردید!\n"
            "شروع به بازی کنید و امتیاز کسب کنید!"
        ),
        'language_set': "✅ زبان با موفقیت به‌روزرسانی شد!",
        'check_balance': (
            "💰 <b>کیف پول شما</b>\n\n"
            "💵 بیلنس: <b>{points} AFG</b>\n"
            "🏆 مجموع برد: <b>{wins}</b>\n"
            "🆔 ID شما: <b>{user_id}</b>\n\n"
            "برای کسب امتیاز بیشتر به بازی ادامه دهید!"
        ),
        'no_active_game': (
            "🎮 <b>بازی فعالی نیست</b>\n\n"
            "در حال حاضر هیچ بازی‌ای در جریان نیست.\n"
            "بعداً بررسی کنید یا منتظر شروع بازی جدید توسط ادمین باشید!"
        ),
        'already_joined': (
            "🎮 <b>قبلاً شرکت کرده‌اید!</b>\n\n"
            "شما قبلاً شماره <b>{number}</b> را برای این بازی انتخاب کرده‌اید.\n"
            "منتظر نتایج باشید!"
        ),
        'join_game': (
            "🎮 <b>به بازی فعلی بپیوندید</b>\n\n"
            "🎯 محدوده: <b>{min_num} - {max_num}</b>\n"
            "💰 هزینه ورود: <b>{cost} AFG</b>\n"
            "💵 بیلنس شما: <b>{balance} AFG</b>\n\n"
            "شماره خوش‌شانس خود را انتخاب کنید:"
        ),
        'not_enough_points': "❌ امتیاز کافی برای شرکت در بازی ندارید!",
        'number_picked': "✅ شماره {number} انتخاب شد! موفق باشید! 🍀",
        'redeem_prompt': (
            "🎁 <b>استفاده از کد هدیه</b>\n\n"
            "کد هدیه خود را در زیر وارد کنید:\n"
            "(کد را تایپ کرده و ارسال کنید)"
        ),
        'redeem_success': (
            "🎉 <b>کد با موفقیت استفاده شد!</b>\n\n"
            "💰 دریافت کردید: <b>{points} AFG</b>\n"
            "💵 بیلنس جدید: <b>{balance} AFG</b>"
        ),
        'redeem_used': "❌ این کد قبلاً استفاده شده است!",
        'redeem_invalid': "❌ کد هدیه نامعتبر است!",
        'top_players': (
            "🏆 <b>جدول رهبری بازیکنان برتر</b>\n\n"
            "{players}\n\n"
            "برای بالا رفتن در رده‌بندی به بازی ادامه دهید!"
        ),
        'help': (
            "ℹ️ <b>نحوه بازی</b>\n\n"
            "🎮 <b>قوانین بازی:</b>\n"
            "• با انتخاب یک شماره در بازی‌های فعال شرکت کنید\n"
            "• هزینه ورود از بیلنس شما کسر می‌شود\n"
            "• برندگان نزدیک‌ترین به شماره مخفی هستند\n"
            "• جایزه بین برندگان تقسیم می‌شود\n\n"
            "💰 <b>کسب امتیاز:</b>\n"
            "• برای کسب AFG بازی‌ها را ببرید\n"
            "• کدهای هدیه را استفاده کنید\n"
            "• از ادمین پاداش دریافت کنید\n\n"
            "🎁 <b>کدهای هدیه:</b>\n"
            "• هر کد فقط یک بار قابل استفاده است\n"
            "• کد را دقیقاً همانطور که نشان داده شده وارد کنید\n\n"
            "موفق باشید و لذت ببرید! 🍀"
        ),
        'back_menu': '🔙 بازگشت به منو'
    }
}

def get_text(language: str, key: str, **kwargs):
    """Get translated text for given language and key"""
    if language not in TRANSLATIONS:
        language = 'english'  # Fallback to English
    
    text = TRANSLATIONS[language].get(key, TRANSLATIONS['english'].get(key, key))
    
    # Format with provided kwargs
    try:
        return text.format(**kwargs)
    except (KeyError, ValueError):
        return text

def get_language_keyboard():
    """Get language selection keyboard data"""
    return [(text, f"lang_{code}") for code, text in LANGUAGES.items()]

def get_supported_languages():
    """Get list of supported language codes"""
    return list(LANGUAGES.keys())
