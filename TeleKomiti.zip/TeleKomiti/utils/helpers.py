"""
Helper functions for Komiti Plus Bot
Includes user management, game logic, gift codes, etc.
"""

import random
import string
from datetime import datetime
from typing import Dict, List, Tuple, Optional

def generate_user_id(existing_users: Dict) -> str:
    """Generate unique 6-digit user ID"""
    while True:
        user_id = ''.join(random.choices(string.digits, k=6))
        # Check if ID already exists
        if not any(user.get('unique_id') == user_id for user in existing_users.values()):
            return user_id

def ensure_unique_user_id(existing_users: Dict) -> str:
    """Ensure generated user ID is unique"""
    return generate_user_id(existing_users)

def generate_gift_code() -> str:
    """Generate unique gift code (10-12 characters)"""
    length = random.randint(10, 12)
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def get_user_profile(users: Dict, user_id: str) -> Optional[Dict]:
    """Get user profile by user ID"""
    return users.get(user_id)

def update_user_profile(users: Dict, user_id: str, updates: Dict) -> bool:
    """Update user profile with new data"""
    if user_id in users:
        users[user_id].update(updates)
        return True
    return False

def get_game_ranges() -> List[Tuple[int, int, int]]:
    """Get available game ranges (min, max, cost)"""
    return [
        (1, 50, 1),
        (1, 100, 2),
        (1, 500, 5),
        (1, 1000, 10)
    ]

def calculate_prize_pool(num_players: int, entry_cost: int) -> int:
    """Calculate total prize pool (half of total collection)"""
    total_collection = num_players * entry_cost
    return total_collection // 2

def find_winners(players: Dict[str, int], winning_number: int) -> List[str]:
    """Find players with closest number to winning number"""
    if not players:
        return []
    
    # Calculate distances
    distances = {}
    for user_id, number in players.items():
        distances[user_id] = abs(number - winning_number)
    
    # Find minimum distance
    min_distance = min(distances.values())
    
    # Return all players with minimum distance
    return [user_id for user_id, distance in distances.items() if distance == min_distance]

def format_winners_list(winners: List[str], users: Dict, prize_per_winner: int) -> str:
    """Format winners list for display"""
    if not winners:
        return "No winners"
    
    result = []
    for winner_id in winners:
        user = users.get(winner_id, {})
        username = user.get('username', 'Unknown')
        result.append(f"• @{username} → {prize_per_winner} AFG")
    
    return '\n'.join(result)

def create_game_history_entry(game_state: Dict, winners: List[str], prize_pool: int) -> Dict:
    """Create game history entry"""
    return {
        'game_id': datetime.now().strftime('%Y%m%d_%H%M%S'),
        'start_time': game_state.get('start_time'),
        'end_time': datetime.now().isoformat(),
        'winning_number': game_state.get('winning_number'),
        'range': f"{game_state.get('min_range')}-{game_state.get('max_range')}",
        'entry_cost': game_state.get('cost'),
        'total_players': len(game_state.get('players', {})),
        'winners': winners,
        'prize_pool': prize_pool,
        'players': dict(game_state.get('players', {}))
    }

def validate_gift_code(gift_codes: Dict, code: str) -> Tuple[bool, str]:
    """Validate gift code"""
    if code not in gift_codes:
        return False, "invalid"
    
    code_data = gift_codes[code]
    if code_data.get('used', False):
        return False, "used"
    
    return True, "valid"

def redeem_gift_code(gift_codes: Dict, users: Dict, code: str, user_id: str) -> Tuple[bool, str, int]:
    """Redeem gift code for user"""
    is_valid, status = validate_gift_code(gift_codes, code)
    
    if not is_valid:
        return False, status, 0
    
    # Redeem the code
    code_data = gift_codes[code]
    points = code_data.get('points', 0)
    
    # Mark as used
    code_data['used'] = True
    code_data['used_by'] = user_id
    code_data['used_at'] = datetime.now().isoformat()
    
    # Add points to user
    if user_id in users:
        users[user_id]['points'] += points
    
    return True, "success", points

def get_top_players(users: Dict, limit: int = 10) -> List[str]:
    """Get top players by points"""
    # Sort users by points (descending) then by wins (descending)
    sorted_users = sorted(
        users.items(),
        key=lambda x: (x[1].get('points', 0), x[1].get('wins', 0)),
        reverse=True
    )
    
    return [user_id for user_id, _ in sorted_users[:limit]]

def format_players_list(top_players: List[str], users: Dict) -> str:
    """Format top players list for display"""
    if not top_players:
        return "No players found"
    
    result = []
    for i, player_id in enumerate(top_players, 1):
        user = users.get(player_id, {})
        username = user.get('username', 'Unknown')
        points = user.get('points', 0)
        wins = user.get('wins', 0)
        unique_id = user.get('unique_id', '000000')
        
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
        result.append(f"{medal} @{username} (ID: {unique_id})\n   💰 {points} AFG | 🏆 {wins} wins")
    
    return '\n\n'.join(result)

def create_gift_code_entry(points: int) -> Dict:
    """Create gift code entry"""
    return {
        'points': points,
        'created_at': datetime.now().isoformat(),
        'used': False,
        'used_by': None,
        'used_at': None
    }

def get_unused_codes(gift_codes: Dict) -> List[Tuple[str, Dict]]:
    """Get list of unused gift codes"""
    return [(code, data) for code, data in gift_codes.items() if not data.get('used', False)]

def format_unused_codes(unused_codes: List[Tuple[str, Dict]]) -> str:
    """Format unused codes list for admin"""
    if not unused_codes:
        return "No unused codes"
    
    result = []
    for code, data in unused_codes:
        points = data.get('points', 0)
        created = data.get('created_at', 'Unknown')
        # Format date
        try:
            created_dt = datetime.fromisoformat(created)
            created_str = created_dt.strftime('%Y-%m-%d %H:%M')
        except:
            created_str = 'Unknown'
        
        result.append(f"• <code>{code}</code> - {points} AFG (Created: {created_str})")
    
    return '\n'.join(result)

def get_game_status_text(game_state: Dict) -> str:
    """Get current game status text"""
    if not game_state.get('active', False):
        return "❌ No active game"
    
    players_count = len(game_state.get('players', {}))
    min_range = game_state.get('min_range', 1)
    max_range = game_state.get('max_range', 50)
    cost = game_state.get('cost', 1)
    
    return (f"✅ Game Active\n"
            f"🎯 Range: {min_range}-{max_range}\n"
            f"💰 Cost: {cost} AFG\n"
            f"👥 Players: {players_count}")

def calculate_game_stats(game_history: Dict) -> Dict:
    """Calculate overall game statistics"""
    if not game_history:
        return {
            'total_games': 0,
            'total_players': 0,
            'total_prizes': 0,
            'average_players': 0
        }
    
    total_games = len(game_history)
    total_players = sum(entry.get('total_players', 0) for entry in game_history.values())
    total_prizes = sum(entry.get('prize_pool', 0) for entry in game_history.values())
    average_players = total_players / total_games if total_games > 0 else 0
    
    return {
        'total_games': total_games,
        'total_players': total_players,
        'total_prizes': total_prizes,
        'average_players': round(average_players, 1)
    }

def get_user_game_history(game_history: Dict, user_id: str) -> List[Dict]:
    """Get game history for specific user"""
    user_games = []
    
    for game_data in game_history.values():
        # Check if user participated
        if user_id in game_data.get('players', {}):
            # Check if user won
            won = user_id in game_data.get('winners', [])
            
            user_games.append({
                'game_id': game_data.get('game_id'),
                'date': game_data.get('end_time'),
                'number_picked': game_data.get('players', {}).get(user_id),
                'winning_number': game_data.get('winning_number'),
                'won': won,
                'prize': game_data.get('prize_pool', 0) // len(game_data.get('winners', [1])) if won else 0
            })
    
    return sorted(user_games, key=lambda x: x['date'], reverse=True)

def format_user_game_history(user_games: List[Dict]) -> str:
    """Format user game history for display"""
    if not user_games:
        return "No game history found"
    
    result = []
    for i, game in enumerate(user_games[:5], 1):  # Show last 5 games
        status = "🏆 WON" if game['won'] else "❌ LOST"
        date = game.get('date', 'Unknown')
        try:
            date_dt = datetime.fromisoformat(date)
            date_str = date_dt.strftime('%m/%d %H:%M')
        except:
            date_str = 'Unknown'
        
        picked = game.get('number_picked', '?')
        winning = game.get('winning_number', '?')
        prize = game.get('prize', 0)
        
        result.append(f"{i}. {status} ({date_str})\n"
                     f"   Your: {picked} | Winning: {winning}")
        
        if game['won']:
            result[-1] += f" | Prize: {prize} AFG"
    
    return '\n\n'.join(result)
