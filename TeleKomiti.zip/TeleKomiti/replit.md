# Overview

**Komiti Plus** is a comprehensive Telegram bot built with Python and the aiogram v3 framework. It implements a sophisticated point-based number guessing game system with multi-language support (English, Pashto, Dari), gift code distribution, user management, and administrative controls. The bot features a complete gaming economy where users earn and spend points to participate in games with varying difficulty levels and rewards.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework Architecture
The application is built on aiogram v3, a modern asynchronous Python framework for Telegram Bot API. This architectural choice provides:
- **Asynchronous operations**: Native async/await support for handling concurrent user requests efficiently
- **Type-safe handlers**: Built-in message routing with proper callback handling and inline keyboard support
- **FSM integration**: Finite State Machine support for multi-step user interactions (code redemption, admin operations)
- **Rich messaging**: HTML parsing mode for formatted messages with buttons and styling

## Data Storage Strategy
The system implements a file-based JSON storage approach with modular data organization:
- **User profiles** (`data/users.json`): Complete user data with unique IDs, language preferences, points, and win statistics
- **Game state** (`data/game_state.json`): Active game management including player lists, game settings, and current status
- **Gift codes** (`data/codes.json`): Code generation and redemption tracking system
- **Game history** (`data/history.json`): Historical game results for analytics and user tracking
- **Admin wallet** (`data/admin_wallet.json`): Administrative point tracking and management

**Rationale**: File-based storage provides simplicity for deployment while maintaining data integrity through modular separation. This approach avoids database dependencies while ensuring easy backup and migration capabilities.

## Game System Architecture
The core game system implements a number guessing game with multiple difficulty tiers:
- **Variable ranges**: Four preset difficulty levels (1-50, 1-100, 1-500, 1-1000) with corresponding entry costs
- **Custom game setup**: Admin can create games with any range and entry cost (e.g., 1-250 range with 15 points cost)
- **Flexible entry costs**: Admin customizable point requirements for each game round (1-1000+ points)
- **Prize pool calculation**: Dynamic reward distribution based on participation and entry fees
- **Winner detection**: Algorithmic winner selection with fair distribution of prizes
- **Game lifecycle management**: Complete game state tracking from creation to completion

## User Management System
- **Dual identification**: Users tracked by both Telegram ID and unique 6-digit system ID
- **Multi-language support**: Complete localization system with language preference storage
- **Point economy**: Comprehensive point system with earning, spending, and transfer capabilities
- **Profile tracking**: Complete user statistics including join date, total wins, and current balance
- **Admin privileges**: Username-based administrative access with full system control

## Security and Access Control
- **Admin authentication**: Username-based admin verification (@Ahmad_khan_111)
- **State management**: Secure FSM implementation for multi-step operations
- **Input validation**: Comprehensive validation for all user inputs and admin commands
- **Permission checks**: Role-based access control for administrative functions

## Internationalization Architecture
- **Language modules**: Separate language handling with utilities for text retrieval
- **Dynamic switching**: Users can change languages at any time with preference persistence
- **Complete coverage**: All user-facing text supports multi-language display
- **Keyboard localization**: Language-specific inline keyboards and button text

# External Dependencies

## Core Framework Dependencies
- **aiogram v3.x**: Modern asynchronous Telegram Bot API framework providing message handling, keyboard management, and FSM support
- **Python 3.12+**: Runtime environment with async/await capabilities

## Telegram Integration
- **Telegram Bot API**: Direct integration through aiogram for message sending, receiving, and callback handling
- **Bot Token**: Environment-configurable authentication token for Telegram API access

## Data Persistence
- **JSON file storage**: No external database dependencies - all data stored in structured JSON files within the `data/` directory
- **File system**: Local file system used for data persistence and configuration storage

## Environment Configuration
- **Environment variables**: Support for BOT_TOKEN and ADMIN_USERNAME configuration through environment variables
- **Default values**: Fallback configuration values for development and testing environments

## Language Support
- **UTF-8 encoding**: Full Unicode support for multi-language text display including Pashto and Dari scripts
- **Custom language utilities**: Internal language management system without external translation services