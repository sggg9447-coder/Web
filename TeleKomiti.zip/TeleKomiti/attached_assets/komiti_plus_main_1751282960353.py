"""
Komiti Plus Telegram Bot - Complete Implementation
Features: Multi-language support, gift codes, enhanced game system, admin controls
"""

import asyncio, json, random, os, re
from datetime import datetime
from aiogram import Bot, Dispatcher, types, F
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

# Import utilities
from utils.language import get_text, get_language_keyboard, LANGUAGES
from utils.helpers import (
    generate_user_id, generate_gift_code, get_user_profile, update_user_profile,
    get_game_ranges, calculate_prize_pool, find_winners, format_winners_list,
    create_game_history_entry, validate_gift_code, redeem_gift_code,
    get_top_players, format_players_list, create_gift_code_entry,
    get_unused_codes, ensure_unique_user_id
)

# === Config ===
BOT_TOKEN = "7738918604:AAHrds_8MiZVXvZf5Od3I775G5pLtOP5I88"
ADMIN_USERNAME = "@Ahmad_khan_111"

# Data files
USERS_FILE = "data/users.json"
GAME_FILE = "data/game_state.json"
CODES_FILE = "data/codes.json"
HISTORY_FILE = "data/history.json"
ADMIN_WALLET_FILE = "data/admin_wallet.json"

# FSM States
class RedeemState(StatesGroup):
    waiting_for_code = State()

class AdminState(StatesGroup):
    waiting_for_points_amount = State()
    waiting_for_target_user = State()
    waiting_for_code_points = State()
    waiting_for_user_to_send_points = State()
    waiting_for_user_to_remove_points = State()

# Ensure data directory exists
os.makedirs("data", exist_ok=True)

# === Helpers: JSON I/O ===
def load_json(path):
    """Load JSON data from file, create empty dict if file doesn't exist"""
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump({}, f)
    with open(path, "r") as f:
        return json.load(f)

def save_json(path, data):
    """Save data to JSON file with proper formatting"""
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# Load initial data
users = load_json(USERS_FILE)
game_state = load_json(GAME_FILE)
gift_codes = load_json(CODES_FILE)
game_history = load_json(HISTORY_FILE)
admin_wallet = load_json(ADMIN_WALLET_FILE)

# Initialize admin wallet if empty
if not admin_wallet:
    admin_wallet = {"points": 0, "total_collected": 0}

# Global variable to store current game task
current_game_task = None

# === Bot Init ===
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=storage)

# === Admin Helper ===
def is_admin(message_or_user) -> bool:
    """Check if user is admin based on username"""
    username = (message_or_user.from_user.username 
                if isinstance(message_or_user, (Message, CallbackQuery)) 
                else message_or_user)
    return (username or "").lower() == ADMIN_USERNAME.lower().replace("@", "")

# === Helper Functions ===
async def save_all_data():
    """Save all data to files"""
    save_json(USERS_FILE, users)
    save_json(GAME_FILE, game_state)
    save_json(CODES_FILE, gift_codes)
    save_json(HISTORY_FILE, game_history)
    save_json(ADMIN_WALLET_FILE, admin_wallet)

async def show_main_menu(msg_or_callback, uid: str, lang: str):
    """Show main menu to user"""
    user = users[uid]
    points = user.get('points', 0)
    user_id = user.get('unique_id', '000000')
    
    # Create main menu keyboard
    kb = InlineKeyboardBuilder()
    kb.button(text="💰 Balance", callback_data="check_balance")
    kb.button(text="🎮 Join Game", callback_data="join_game")
    kb.button(text="🎁 Redeem Code", callback_data="redeem_code")
    kb.button(text="🌐 Language", callback_data="change_language")
    
    if is_admin(msg_or_callback):
        kb.button(text="⚙️ Admin Panel", callback_data="admin_panel")
    
    kb.button(text="ℹ️ Help", callback_data="help")
    kb.button(text="🏆 Top Players", callback_data="top_players")
    kb.adjust(2)
    
    text = get_text(lang, 'main_menu', points=points, user_id=user_id)
    
    if isinstance(msg_or_callback, Message):
        await msg_or_callback.answer(text, reply_markup=kb.as_markup())
    else:
        await msg_or_callback.message.edit_text(text, reply_markup=kb.as_markup())

# === /start Command ===
@dp.message(F.text == "/start")
async def cmd_start(msg: Message):
    """Handle /start command with language selection for new users"""
    uid = str(msg.from_user.id)
    username = msg.from_user.username or f"User{uid}"
    
    if uid not in users:
        # New user - show language selection first
        kb = InlineKeyboardBuilder()
        for lang_text, lang_data in get_language_keyboard():
            kb.button(text=lang_text, callback_data=lang_data)
        kb.adjust(1)
        
        await msg.answer(
            "🎉 Welcome to **Komiti Plus**!\n\n"
            "Please select your language / د خپلې ژبې غوره کړئ / زبان خود را انتخاب کنید:",
            reply_markup=kb.as_markup()
        )
    else:
        # Existing user - show main menu
        user = users[uid]
        lang = user.get('language', 'english')
        await show_main_menu(msg, uid, lang)

# === Language Selection ===
@dp.callback_query(F.data.startswith("lang_"))
async def cb_language_select(callback: CallbackQuery):
    """Handle language selection"""
    uid = str(callback.from_user.id)
    username = callback.from_user.username or f"User{uid}"
    selected_lang = callback.data.split("_")[1]
    
    # Create or update user profile
    if uid not in users:
        users[uid] = {
            'telegram_id': uid,
            'username': username,
            'unique_id': ensure_unique_user_id(users),
            'points': 1,  # Starting bonus
            'wins': 0,
            'language': selected_lang,
            'join_date': datetime.now().isoformat()
        }
        
        # Welcome new user
        text = get_text(selected_lang, 'welcome_new')
    else:
        # Update existing user's language
        users[uid]['language'] = selected_lang
        text = get_text(selected_lang, 'language_set')
    
    await save_all_data()
    await callback.answer(get_text(selected_lang, 'language_set'))
    await show_main_menu(callback, uid, selected_lang)

# === Main Menu Callbacks ===
@dp.callback_query(F.data == "check_balance")
async def cb_check_balance(callback: CallbackQuery):
    """Handle balance check button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    points = user.get('points', 0)
    wins = user.get('wins', 0)
    user_id = user.get('unique_id', '000000')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'check_balance', points=points, wins=wins, user_id=user_id)
    
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "join_game")
async def cb_join_game(callback: CallbackQuery):
    """Handle join game button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    if not game_state.get("active"):
        kb = InlineKeyboardBuilder()
        kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
        
        text = get_text(lang, 'no_active_game')
        await callback.message.edit_text(text, reply_markup=kb.as_markup())
        await callback.answer()
        return
    
    if uid in game_state.get("players", {}):
        kb = InlineKeyboardBuilder()
        kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
        
        picked_num = game_state["players"][uid]
        text = get_text(lang, 'already_joined', number=picked_num)
        await callback.message.edit_text(text, reply_markup=kb.as_markup())
        await callback.answer()
        return
    
    # Show number selection
    min_num = game_state.get("min_range", 1)
    max_num = game_state.get("max_range", 50)
    cost = game_state.get("cost", 1)
    balance = user.get('points', 0)
    
    if balance < cost:
        await callback.answer(get_text(lang, 'not_enough_points'), show_alert=True)
        return
    
    # Create number selection keyboard
    kb = InlineKeyboardBuilder()
    for i in range(min_num, max_num + 1):
        kb.button(text=str(i), callback_data=f"pick_{i}")
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    kb.adjust(5)
    
    text = get_text(lang, 'join_game', min_num=min_num, max_num=max_num, cost=cost, balance=balance)
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data.startswith("pick_"))
async def cb_pick_number(callback: CallbackQuery):
    """Handle number selection"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    if not game_state.get("active"):
        await callback.answer(get_text(lang, 'no_active_game'), show_alert=True)
        return
    
    if uid in game_state.get("players", {}):
        await callback.answer("Already joined!", show_alert=True)
        return
    
    cost = game_state.get("cost", 1)
    if user.get('points', 0) < cost:
        await callback.answer(get_text(lang, 'not_enough_points'), show_alert=True)
        return
    
    # Process the pick
    num = int(callback.data.split("_")[1])
    
    # Update game state
    if "players" not in game_state:
        game_state["players"] = {}
    game_state["players"][uid] = num
    
    # Deduct entry fee and add to admin wallet
    users[uid]['points'] -= cost
    admin_wallet['points'] += cost
    admin_wallet['total_collected'] += cost
    
    await save_all_data()
    
    text = get_text(lang, 'number_picked', number=num)
    await callback.answer(text)
    
    # Return to main menu
    await show_main_menu(callback, uid, lang)

@dp.callback_query(F.data == "redeem_code")
async def cb_redeem_code(callback: CallbackQuery, state: FSMContext):
    """Handle redeem code button"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'redeem_prompt')
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await state.set_state(RedeemState.waiting_for_code)
    await callback.answer()

@dp.message(RedeemState.waiting_for_code)
async def handle_redeem_code(msg: Message, state: FSMContext):
    """Handle gift code redemption"""
    uid = str(msg.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    code = msg.text.strip().upper()
    
    success, result, points = redeem_gift_code(gift_codes, users, code, uid)
    
    if success:
        text = get_text(lang, 'redeem_success', points=points, balance=users[uid]['points'])
    elif result == "used":
        text = get_text(lang, 'redeem_used')
    else:
        text = get_text(lang, 'redeem_invalid')
    
    await save_all_data()
    await msg.answer(text)
    await state.clear()
    
    # Show main menu
    await show_main_menu(msg, uid, lang)

@dp.callback_query(F.data == "change_language")
async def cb_change_language(callback: CallbackQuery):
    """Handle language change"""
    kb = InlineKeyboardBuilder()
    for lang_text, lang_data in get_language_keyboard():
        kb.button(text=lang_text, callback_data=lang_data)
    kb.adjust(1)
    
    await callback.message.edit_text(
        "Select your language / د خپلې ژبې غوره کړئ / زبان خود را انتخاب کنید:",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

@dp.callback_query(F.data == "top_players")
async def cb_top_players(callback: CallbackQuery):
    """Show top players leaderboard"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    top_players_list = get_top_players(users, 10)
    players_text = format_players_list(top_players_list, users)
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'top_players', players=players_text)
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "help")
async def cb_help(callback: CallbackQuery):
    """Show help information"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    kb = InlineKeyboardBuilder()
    kb.button(text=get_text(lang, 'back_menu'), callback_data="main_menu")
    
    text = get_text(lang, 'help_text')
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "main_menu")
async def cb_main_menu(callback: CallbackQuery):
    """Return to main menu"""
    uid = str(callback.from_user.id)
    user = users.get(uid, {})
    lang = user.get('language', 'english')
    
    await show_main_menu(callback, uid, lang)
    await callback.answer()

# === Admin Panel ===
@dp.callback_query(F.data == "admin_panel")
async def cb_admin_panel(callback: CallbackQuery):
    """Show admin panel"""
    if not is_admin(callback):
        await callback.answer("⛔ You're not an admin!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    
    if game_state.get("active"):
        kb.button(text="🛑 End Game", callback_data="admin_end_game")
        kb.button(text="👥 Game Stats", callback_data="admin_game_stats")
    else:
        kb.button(text="🎮 Start Game", callback_data="admin_start_game")
    
    kb.button(text="💰 Send Points", callback_data="admin_send_points")
    kb.button(text="💸 Remove Points", callback_data="admin_remove_points")
    kb.button(text="🎁 Generate Code", callback_data="admin_generate_code")
    kb.button(text="👥 Players List", callback_data="admin_players")
    kb.button(text="📊 Admin Stats", callback_data="admin_stats")
    kb.button(text="🔙 Back to Menu", callback_data="main_menu")
    kb.adjust(2)
    
    game_status = get_text('english', 'active') if game_state.get("active") else get_text('english', 'inactive')
    total_users = len(users)
    
    text = get_text('english', 'admin_panel', status=game_status, users=total_users)
    
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()

@dp.callback_query(F.data == "admin_start_game")
async def cb_admin_start_game(callback: CallbackQuery):
    """Show game start options"""
    if not is_admin(callback):
        await callback.answer("⛔ You're not an admin!", show_alert=True)
        return
    
    kb = InlineKeyboardBuilder()
    ranges = get_game_ranges()
    
    for min_r, max_r, display in ranges:
        kb.button(text=f"Range {display}", callback_data=f"start_game_{min_r}_{max_r}")
    
    kb.button(text="🔙 Back to Admin", callback_data="admin_panel")
    kb.adjust(2)
    
    await callback.message.edit_text(
        "🎮 **Start New Game**\n\nSelect number range:",
        reply_markup=kb.as_markup()
    )
    await callback.answer()

@dp.callback_query(F.data.startswith("start_game_"))
async def cb_start_specific_game(callback: CallbackQuery):
    """Start game with specific range"""
    if not is_admin(callback):
        await callback.answer("⛔ You're not an admin!", show_alert=True)
        return
    
    parts = callback.data.split("_")
    min_range = int(parts[2])
    max_range = int(parts[3])
    
    # Initialize game state
    game_state.update({
        "active": True,
        "min_range": min_range,
        "max_range": max_range,
        "cost": 1,  # Default cost
        "players": {},
        "winning_number": random.randint(min_range, max_range),
        "start_time": datetime.now().isoformat()
    })
    
    await save_all_data()
    
    # Schedule game to end after 1 hour
    async def auto_end_game():
        await asyncio.sleep(3600)  # 1 hour
        if game_state.get("active"):
            await end_game_automated()
    
    global current_game_task
    current_game_task = asyncio.create_task(auto_end_game())
    
    text = get_text('english', 'game_started', 
                   min_num=min_range, max_num=max_range, 
                   duration="1 hour", cost=1)
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back to Admin", callback_data="admin_panel")
    
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer("Game started successfully!")

@dp.callback_query(F.data == "admin_end_game")
async def cb_admin_end_game(callback: CallbackQuery):
    """End current game"""
    if not is_admin(callback):
        await callback.answer("⛔ You're not an admin!", show_alert=True)
        return
    
    await end_game_with_callback(callback)

async def end_game_automated():
    """End game automatically"""
    if not game_state.get("active"):
        return
    
    await process_game_end()

async def end_game_with_callback(callback: CallbackQuery):
    """End game with callback response"""
    if not game_state.get("active"):
        kb = InlineKeyboardBuilder()
        kb.button(text="🔙 Back to Admin", callback_data="admin_panel")
        
        await callback.message.edit_text(
            "ℹ️ No game in progress.",
            reply_markup=kb.as_markup()
        )
        await callback.answer()
        return
    
    result_text = await process_game_end()
    
    kb = InlineKeyboardBuilder()
    kb.button(text="🔙 Back to Admin", callback_data="admin_panel")
    
    await callback.message.edit_text(result_text, reply_markup=kb.as_markup())
    await callback.answer("Game ended successfully!")

async def process_game_end():
    """Process game ending logic"""
    global current_game_task
    
    # Cancel auto-end task if running
    if current_game_task and not current_game_task.cancelled():
        current_game_task.cancel()
        current_game_task = None
    
    winning_number = game_state.get("winning_number", 1)
    players = game_state.get("players", {})
    cost = game_state.get("cost", 1)
    
    if not players:
        result_text = get_text('english', 'game_ended_no_winners')
    else:
        # Find winners
        winners = find_winners(players, winning_number)
        
        # Calculate prizes (half of collected goes to winners)
        total_prize_pool = calculate_prize_pool(len(players), cost)
        prize_per_winner = total_prize_pool // len(winners) if winners else 0
        
        # Award prizes to winners
        for uid in winners:
            if uid in users:
                users[uid]['points'] += prize_per_winner
                users[uid]['wins'] += 1
        
        # Deduct from admin wallet
        admin_wallet['points'] -= total_prize_pool
        
        # Format winners list
        winners_text = format_winners_list(winners, users, prize_per_winner)
        result_text = get_text('english', 'game_ended', 
                             winning_number=winning_number,
                             prize=prize_per_winner,
                             winners=winners_text)
        
        # Save to history
        history_entry = create_game_history_entry(
            winning_number, players, winners, prize_per_winner, 
            cost, (game_state.get("min_range", 1), game_state.get("max_range", 50))
        )
        
        if not isinstance(game_history, list):
            game_history.clear()
            game_history.extend([])
        game_history.append(history_entry)
    
    # Reset game state
    game_state.clear()
    game_state.update({"active": False})
    
    await save_all_data()
    return result_text

# === Admin Commands ===
@dp.message(F.text.startswith("/sendpoints"))
async def cmd_send_points(msg: Message):
    """Send points to user - /sendpoints @username 10"""
    if not is_admin(msg):
        return await msg.answer("⛔ You're not the admin.")
    
    parts = msg.text.split()
    if len(parts) != 3:
        return await msg.answer("Usage: /sendpoints @username 10")
    
    target_username = parts[1].replace("@", "").lower()
    try:
        points = int(parts[2])
    except ValueError:
        return await msg.answer("Invalid points amount!")
    
    # Find user by username
    target_uid = None
    for uid, user_data in users.items():
        if user_data.get('username', '').lower() == target_username:
            target_uid = uid
            break
    
    if not target_uid:
        return await msg.answer(get_text('english', 'user_not_found'))
    
    # Add points to user
    users[target_uid]['points'] += points
    await save_all_data()
    
    text = get_text('english', 'points_sent', points=points, username=target_username)
    await msg.answer(text)

@dp.message(F.text.startswith("/removepoints"))
async def cmd_remove_points(msg: Message):
    """Remove points from user - /removepoints @username 5"""
    if not is_admin(msg):
        return await msg.answer("⛔ You're not the admin.")
    
    parts = msg.text.split()
    if len(parts) != 3:
        return await msg.answer("Usage: /removepoints @username 5")
    
    target_username = parts[1].replace("@", "").lower()
    try:
        points = int(parts[2])
    except ValueError:
        return await msg.answer("Invalid points amount!")
    
    # Find user by username
    target_uid = None
    for uid, user_data in users.items():
        if user_data.get('username', '').lower() == target_username:
            target_uid = uid
            break
    
    if not target_uid:
        return await msg.answer(get_text('english', 'user_not_found'))
    
    # Remove points from user
    users[target_uid]['points'] = max(0, users[target_uid]['points'] - points)
    await save_all_data()
    
    text = get_text('english', 'points_removed', points=points, username=target_username)
    await msg.answer(text)

@dp.message(F.text.startswith("/generatecode"))
async def cmd_generate_code(msg: Message):
    """Generate gift code - /generatecode 20"""
    if not is_admin(msg):
        return await msg.answer("⛔ You're not the admin.")
    
    parts = msg.text.split()
    if len(parts) != 2:
        return await msg.answer("Usage: /generatecode 20")
    
    try:
        points = int(parts[1])
    except ValueError:
        return await msg.answer("Invalid points amount!")
    
    # Generate unique code
    code = generate_gift_code()
    gift_codes[code] = create_gift_code_entry(code, points)
    
    await save_all_data()
    
    text = get_text('english', 'code_generated', code=code, points=points)
    await msg.answer(text)

@dp.message(F.text == "/players")
async def cmd_players(msg: Message):
    """Show players list"""
    if not is_admin(msg):
        return await msg.answer("⛔ You're not the admin.")
    
    if game_state.get("active"):
        players = game_state.get("players", {})
        if players:
            player_lines = []
            for uid, number in players.items():
                user_data = users.get(uid, {})
                username = user_data.get('username', f'User{uid}')
                unique_id = user_data.get('unique_id', '000000')
                player_lines.append(f"• @{username} (ID: {unique_id}) → {number}")
            
            players_text = "\n".join(player_lines)
            text = get_text('english', 'players_list', count=len(players), players=players_text)
        else:
            text = "👥 **Current Players (0)**\n\nNo players joined yet."
    else:
        text = "ℹ️ No active game to show players."
    
    await msg.answer(text)

# === Main Function ===
async def main():
    """Start the bot"""
    print("🤖 Komiti Plus Bot is starting...")
    print(f"📊 Loaded {len(users)} users")
    print(f"🎮 Game active: {game_state.get('active', False)}")
    print(f"🎁 Gift codes: {len(gift_codes)}")
    print("✅ Bot is running and ready for commands!")
    
    # Start polling for messages
    await dp.start_polling(bot)

if __name__ == "__main__":
    # Run the bot
    asyncio.run(main())